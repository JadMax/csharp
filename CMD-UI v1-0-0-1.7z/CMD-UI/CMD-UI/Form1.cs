﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace CMD_UI
{
    public partial class mainWindow : Form
    {
        public mainWindow()
        {
            InitializeComponent();
            mkl_linkTypeBox.SelectedIndex = 0;
        }

        private void mkl_browseLinkBtn_Click(object sender, EventArgs e)
        {
            mkl_folderBrowser.ShowDialog();
            mkl_linkTxtbx.Text = mkl_folderBrowser.SelectedPath;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mkl_folderBrowser.ShowDialog();
            mkl_targetTxtbx.Text = mkl_folderBrowser.SelectedPath;
        }

        bool isLinkExist = false;
        bool isTargetExist = false;
        bool isTargetUnderRootDisk = false;
        string[] splittedTarget;
        string splittedTargetLast;
        private void mkl_linkStartBtn_Click(object sender, EventArgs e)
        {
            isLinkExist = Directory.Exists(mkl_linkTxtbx.Text);
            isTargetExist = Directory.Exists(mkl_targetTxtbx.Text);

            splittedTarget = Regex.Split(mkl_targetTxtbx.Text, "\\\\",RegexOptions.Compiled);
            splittedTargetLast = splittedTarget[splittedTarget.Length - 1];

            if (splittedTargetLast == "")
            {
                isTargetUnderRootDisk = true;
            }
            else
            {
                isTargetUnderRootDisk = false;
            }

            if (!isLinkExist)
            {
                MessageBox.Show("请检查欲链接到的位置(Link)是否存在！");
                mkl_linkTxtbx.Focus();
            }
            if (!isTargetExist)
            {
                MessageBox.Show("请检查目标文件夹目录(Target)是否存在！");
                mkl_targetTxtbx.Focus();
            }
            if (isTargetUnderRootDisk && isTargetExist)
            {
                MessageBox.Show("请勿将目标文件夹目录(Target)设为磁盘根目录！");
                mkl_targetTxtbx.Focus();
            }
            
            if (isLinkExist && isTargetExist && !isTargetUnderRootDisk)
            {
                MklinkCreateLinker(Application.StartupPath + "\\mklinker.cmd", "j", mkl_linkTxtbx.Text + splittedTargetLast, mkl_targetTxtbx.Text);
                RunMklinker();
            }

        }

        private void MklinkCreateLinker(string path, string linkType, string link, string target)
        {
            linkType = linkTypes;
            File.WriteAllText(path,
                "mklink /" + linkType + " \"" + link + "\" \"" + target + "\"",Encoding.Default);
        }
        private void RunMklinker()
        {
            Process process = new Process();
            process.StartInfo.FileName = Application.StartupPath + "\\mklinker.cmd";
            process.Start();
        }

        private string linkTypes;
        private void mkl_linkTypeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (mkl_linkTypeBox.SelectedIndex == 0)
                linkTypes = "d";
            if (mkl_linkTypeBox.SelectedIndex == 1)
                linkTypes = "h";
            if (mkl_linkTypeBox.SelectedIndex == 2)
                linkTypes = "j";
        }
    }
}
