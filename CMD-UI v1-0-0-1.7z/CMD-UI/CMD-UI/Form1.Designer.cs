﻿namespace CMD_UI
{
    partial class mainWindow
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.mkLinker = new System.Windows.Forms.TabPage();
            this.mkl_linkStartBtn = new System.Windows.Forms.Button();
            this.mkl_browseTargetBtn = new System.Windows.Forms.Button();
            this.mkl_targetTxtbx = new System.Windows.Forms.TextBox();
            this.mkl_targetTxt = new System.Windows.Forms.Label();
            this.mkl_browseLinkBtn = new System.Windows.Forms.Button();
            this.mkl_linkTxtbx = new System.Windows.Forms.TextBox();
            this.mkl_linkTxt = new System.Windows.Forms.Label();
            this.mkl_linkTypeBox = new System.Windows.Forms.ComboBox();
            this.mkl_chooseTypeTxt = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.mkl_folderBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.versionTxt = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.mkLinker.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.mkLinker);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(531, 429);
            this.tabControl.TabIndex = 0;
            // 
            // mkLinker
            // 
            this.mkLinker.Controls.Add(this.mkl_linkStartBtn);
            this.mkLinker.Controls.Add(this.mkl_browseTargetBtn);
            this.mkLinker.Controls.Add(this.mkl_targetTxtbx);
            this.mkLinker.Controls.Add(this.mkl_targetTxt);
            this.mkLinker.Controls.Add(this.mkl_browseLinkBtn);
            this.mkLinker.Controls.Add(this.mkl_linkTxtbx);
            this.mkLinker.Controls.Add(this.mkl_linkTxt);
            this.mkLinker.Controls.Add(this.mkl_linkTypeBox);
            this.mkLinker.Controls.Add(this.mkl_chooseTypeTxt);
            this.mkLinker.Location = new System.Drawing.Point(4, 26);
            this.mkLinker.Name = "mkLinker";
            this.mkLinker.Padding = new System.Windows.Forms.Padding(3);
            this.mkLinker.Size = new System.Drawing.Size(523, 399);
            this.mkLinker.TabIndex = 0;
            this.mkLinker.Text = "Mk Linker";
            this.mkLinker.UseVisualStyleBackColor = true;
            // 
            // mkl_linkStartBtn
            // 
            this.mkl_linkStartBtn.Location = new System.Drawing.Point(297, 95);
            this.mkl_linkStartBtn.Name = "mkl_linkStartBtn";
            this.mkl_linkStartBtn.Size = new System.Drawing.Size(75, 23);
            this.mkl_linkStartBtn.TabIndex = 8;
            this.mkl_linkStartBtn.Text = "Link Start!";
            this.mkl_linkStartBtn.UseVisualStyleBackColor = true;
            this.mkl_linkStartBtn.Click += new System.EventHandler(this.mkl_linkStartBtn_Click);
            // 
            // mkl_browseTargetBtn
            // 
            this.mkl_browseTargetBtn.Location = new System.Drawing.Point(342, 66);
            this.mkl_browseTargetBtn.Name = "mkl_browseTargetBtn";
            this.mkl_browseTargetBtn.Size = new System.Drawing.Size(30, 23);
            this.mkl_browseTargetBtn.TabIndex = 7;
            this.mkl_browseTargetBtn.Text = "...";
            this.mkl_browseTargetBtn.UseVisualStyleBackColor = true;
            this.mkl_browseTargetBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // mkl_targetTxtbx
            // 
            this.mkl_targetTxtbx.Location = new System.Drawing.Point(157, 66);
            this.mkl_targetTxtbx.Name = "mkl_targetTxtbx";
            this.mkl_targetTxtbx.Size = new System.Drawing.Size(179, 23);
            this.mkl_targetTxtbx.TabIndex = 6;
            // 
            // mkl_targetTxt
            // 
            this.mkl_targetTxt.AutoSize = true;
            this.mkl_targetTxt.Location = new System.Drawing.Point(6, 69);
            this.mkl_targetTxt.Name = "mkl_targetTxt";
            this.mkl_targetTxt.Size = new System.Drawing.Size(145, 17);
            this.mkl_targetTxt.TabIndex = 5;
            this.mkl_targetTxt.Text = "目标文件夹目录 (Target):";
            // 
            // mkl_browseLinkBtn
            // 
            this.mkl_browseLinkBtn.Location = new System.Drawing.Point(342, 39);
            this.mkl_browseLinkBtn.Name = "mkl_browseLinkBtn";
            this.mkl_browseLinkBtn.Size = new System.Drawing.Size(30, 23);
            this.mkl_browseLinkBtn.TabIndex = 4;
            this.mkl_browseLinkBtn.Text = "...";
            this.mkl_browseLinkBtn.UseVisualStyleBackColor = true;
            this.mkl_browseLinkBtn.Click += new System.EventHandler(this.mkl_browseLinkBtn_Click);
            // 
            // mkl_linkTxtbx
            // 
            this.mkl_linkTxtbx.Location = new System.Drawing.Point(157, 37);
            this.mkl_linkTxtbx.Name = "mkl_linkTxtbx";
            this.mkl_linkTxtbx.Size = new System.Drawing.Size(179, 23);
            this.mkl_linkTxtbx.TabIndex = 3;
            // 
            // mkl_linkTxt
            // 
            this.mkl_linkTxt.AutoSize = true;
            this.mkl_linkTxt.Location = new System.Drawing.Point(6, 42);
            this.mkl_linkTxt.Name = "mkl_linkTxt";
            this.mkl_linkTxt.Size = new System.Drawing.Size(130, 17);
            this.mkl_linkTxt.TabIndex = 2;
            this.mkl_linkTxt.Text = "欲链接到的位置 (Link):";
            // 
            // mkl_linkTypeBox
            // 
            this.mkl_linkTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mkl_linkTypeBox.FormattingEnabled = true;
            this.mkl_linkTypeBox.Items.AddRange(new object[] {
            "/D - (文件)符号链接",
            "/H - 硬链接",
            "/J - 目录链接"});
            this.mkl_linkTypeBox.Location = new System.Drawing.Point(157, 6);
            this.mkl_linkTypeBox.Name = "mkl_linkTypeBox";
            this.mkl_linkTypeBox.Size = new System.Drawing.Size(179, 25);
            this.mkl_linkTypeBox.TabIndex = 1;
            this.mkl_linkTypeBox.SelectedIndexChanged += new System.EventHandler(this.mkl_linkTypeBox_SelectedIndexChanged);
            // 
            // mkl_chooseTypeTxt
            // 
            this.mkl_chooseTypeTxt.AutoSize = true;
            this.mkl_chooseTypeTxt.Location = new System.Drawing.Point(6, 9);
            this.mkl_chooseTypeTxt.Name = "mkl_chooseTypeTxt";
            this.mkl_chooseTypeTxt.Size = new System.Drawing.Size(111, 17);
            this.mkl_chooseTypeTxt.TabIndex = 0;
            this.mkl_chooseTypeTxt.Text = "选择 Mk-link 方法:";
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(523, 390);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "(WIP)";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // versionTxt
            // 
            this.versionTxt.AutoSize = true;
            this.versionTxt.Location = new System.Drawing.Point(399, 444);
            this.versionTxt.Name = "versionTxt";
            this.versionTxt.Size = new System.Drawing.Size(144, 17);
            this.versionTxt.TabIndex = 1;
            this.versionTxt.Text = "CMD-UI Version 1.0.0.1";
            // 
            // mainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(555, 470);
            this.Controls.Add(this.versionTxt);
            this.Controls.Add(this.tabControl);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "mainWindow";
            this.Text = "CMD UI";
            this.tabControl.ResumeLayout(false);
            this.mkLinker.ResumeLayout(false);
            this.mkLinker.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage mkLinker;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label mkl_chooseTypeTxt;
        private System.Windows.Forms.ComboBox mkl_linkTypeBox;
        private System.Windows.Forms.TextBox mkl_linkTxtbx;
        private System.Windows.Forms.Label mkl_linkTxt;
        private System.Windows.Forms.FolderBrowserDialog mkl_folderBrowser;
        private System.Windows.Forms.Button mkl_browseLinkBtn;
        private System.Windows.Forms.Label mkl_targetTxt;
        private System.Windows.Forms.TextBox mkl_targetTxtbx;
        private System.Windows.Forms.Button mkl_browseTargetBtn;
        private System.Windows.Forms.Button mkl_linkStartBtn;
        private System.Windows.Forms.Label versionTxt;
    }
}

